package com.text.browsetext;

import java.time.Duration;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
        
        
        ChromeOptions option = new ChromeOptions();
        option.addArguments("--remote-allow-origins=*","ignore-certificate-errors");
        //System.setProperty("webdriver.http.factory", "jdk-http-client");
        System.setProperty("webdriver.chrome.driver", "C:\\Chandra\\chromedriver\\chromedriver.exe");

        WebDriver driver = new ChromeDriver(option);
        
        driver.navigate().to("https://rbi.org.in/scripts/ReferenceRateArchive.aspx");

        System.out.println("Title:"+driver.getTitle());
        
        try {
			Thread.sleep(10000);//10 secns sleep before checking below actions
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        
        driver.findElement(By.xpath("//input[@id='chkUSD']")).click();
       
        //ui-state-default ui-state-highlight
        driver.findElement(By.xpath("//input[@id='txtFromDate']")).click();//custom_range hasDatepicker - //input[@id='txtFromDate']
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement dateWidgetFrom = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("ui-datepicker-calendar"))).get(0);
            //This are the columns of the from date picker table
            List<WebElement> columns = dateWidgetFrom.findElements(By.tagName("td"));
            columns.stream()
            .filter(element -> element.getText().contains("14"))
            .findFirst()
            .ifPresent(WebElement::click);
        
        driver.findElement(By.xpath("//input[@id='txtToDate']")).click();
        
        WebElement dateWidgetTo = wait.until(
                ExpectedConditions.visibilityOfAllElementsLocatedBy(By.className("ui-datepicker-calendar"))).get(0);
            //This are the columns of the from date picker table
            List<WebElement> columnsTo = dateWidgetTo.findElements(By.tagName("td"));
        clickGivenDay(columnsTo, "16");
        driver.findElement(By.xpath("//input[@id='btnSubmit']")).click();
        System.out.println("Button submitted:");
    }
    
    public static void clickGivenDay(List<WebElement> elementList, String day) {
        //DatePicker is a table. Thus we can navigate to each cell
        //and if a cell matches with the current date then we will click it.
        /**Functional JAVA version of this method.*/
        elementList.stream()
            .filter(element -> element.getText().contains(day))
            .findFirst()
            .ifPresent(WebElement::click);
        /**Non-functional JAVA version of this method.*/
        //for (
        //    WebElement cell : elementList) {
        //    String cellText = cell.getText();
        //    if (cellText.contains(day)) {
        //        cell.click();
        //        break;
        //    }
        //}
    }
    
    public static String getCurrentDay() {
        //Create a Calendar Object
        Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
        //Get Current Day as a number
        int todayInt = calendar.get(Calendar.DAY_OF_MONTH);
        System.out.println("Today Int: " + todayInt + "\n");
        //Integer to String Conversion
        String todayStr = Integer.toString(todayInt);
        System.out.println("Today Str: " + todayStr + "\n");
        return todayStr;
    }
    
    public static void selectDate(WebDriver driver, String day) throws InterruptedException
    { 
	    
	   
	    //Selecting the date 
	    List<WebElement> days = driver.findElements(By.xpath("//div[@data-handler='selectDay']"));
		for (WebElement d : days) {
			System.out.println(d.getText());
			if (d.getText().equals(day)) {
				d.click();
				Thread.sleep(10000);
				System.out.println("from date sleep");
				return;
			}
		}
	   
	    
    }
    
    
}
